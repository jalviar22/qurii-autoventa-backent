# Qurii Autoventa Backend (FastAPI)

Sistema backend para ahorro programado.

[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app/template/new?repo=https://github.com/tu-usuario/Qurii-autoventa-backend)

