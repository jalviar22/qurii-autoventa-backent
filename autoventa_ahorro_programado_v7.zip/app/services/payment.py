import requests
from app.config import CREDIBANCO_API_KEY, CREDIBANCO_SECRET_KEY, CREDIBANCO_MERCHANT_ID, CREDIBANCO_BASE_URL

def process_credibanco_payment(user_id: int, amount: float, payment_method: str):
    headers = {
        "Content-Type": "application/json",
        "Api-Key": CREDIBANCO_API_KEY,
        "Api-Secret": CREDIBANCO_SECRET_KEY,
    }
    payload = {
        "merchant_id": CREDIBANCO_MERCHANT_ID,
        "amount": int(amount * 100),
        "currency": "COP",
        "reference": f"user-{user_id}-tx",
        "description": "Pago plan de ahorro programado",
        "payment_method": payment_method,
        "callback_url": "https://tuservidor.com/callback"
    }
    try:
        response = requests.post(f"{CREDIBANCO_BASE_URL}/v1/payments", headers=headers, json=payload)
        response.raise_for_status()
        return response.json()
    except requests.RequestException as e:
        return {"status": "error", "detail": str(e)}
