from fastapi import APIRouter
from pydantic import BaseModel
from app.services import payment as credibanco_payment

router = APIRouter(prefix="/payments", tags=["payments"])

class PaymentRequest(BaseModel):
    user_id: int
    amount: float
    payment_method: str

class PaymentResponse(BaseModel):
    status: str
    transaction_id: str | None = None
    detail: str | None = None

@router.post("/pay", response_model=PaymentResponse)
def process_payment(payment: PaymentRequest):
    result = credibanco_payment.process_credibanco_payment(
        user_id=payment.user_id,
        amount=payment.amount,
        payment_method=payment.payment_method
    )
    return PaymentResponse(
        status=result.get("status", "error"),
        transaction_id=result.get("transaction_id"),
        detail=result.get("detail")
    )
