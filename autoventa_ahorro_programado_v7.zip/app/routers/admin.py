from fastapi import APIRouter
from pydantic import BaseModel
from typing import List

router = APIRouter(prefix="/admin", tags=["admin"])

class Subscriber(BaseModel):
    id: int
    full_name: str
    email: str
    status: str  # Ej: "Activo", "Adjudicado", "Moroso"

class Group(BaseModel):
    group_id: int
    members: List[Subscriber]
    adjudicated_ids: List[int]

@router.get("/groups", response_model=List[Group])
def list_groups():
    # Simulación de 2 grupos
    return [
        Group(
            group_id=1,
            members=[
                Subscriber(id=1, full_name="Carlos Pérez", email="carlos@example.com", status="Activo"),
                Subscriber(id=2, full_name="Laura Ruiz", email="laura@example.com", status="Adjudicado")
            ],
            adjudicated_ids=[2]
        ),
        Group(
            group_id=2,
            members=[
                Subscriber(id=3, full_name="Sofía López", email="sofia@example.com", status="Activo"),
                Subscriber(id=4, full_name="Miguel Torres", email="miguel@example.com", status="Activo")
            ],
            adjudicated_ids=[]
        )
    ]
