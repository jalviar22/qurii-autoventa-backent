import os

CREDIBANCO_API_KEY = os.getenv("CREDIBANCO_API_KEY", "your-api-key-here")
CREDIBANCO_SECRET_KEY = os.getenv("CREDIBANCO_SECRET_KEY", "your-secret-key-here")
CREDIBANCO_MERCHANT_ID = os.getenv("CREDIBANCO_MERCHANT_ID", "your-merchant-id-here")
CREDIBANCO_BASE_URL = os.getenv("CREDIBANCO_BASE_URL", "https://sandbox-api.credibanco.com")
